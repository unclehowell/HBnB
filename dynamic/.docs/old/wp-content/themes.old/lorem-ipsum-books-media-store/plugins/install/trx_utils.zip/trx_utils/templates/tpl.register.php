<?php
/**
 * The template to display register link and popup
 *
 * @package WordPress
 * @subpackage ThemeREX Utilities
 * @since v3.0
 */

// Display link
$args = get_query_var('trx_utils_args_register');
$unique = uniqid();
static $cnt = 0;
$cnt++;
$privacy = trx_utils_get_privacy_text();

?><a href="#popup_registration_<?php echo esc_attr($unique); ?>" class="popup_link popup_register_link icon-pencil" title="<?php echo esc_attr($args['link_title']); ?>"><?php echo esc_html($args['link_text']); ?></a><?php

// Prepare popup
?>
<div id="popup_registration_<?php echo esc_attr($unique); ?>" class="popup_wrap popup_registration bg_tint_light">
	<a href="#" class="popup_close"></a>
	<div class="form_wrap">
		<form name="registration_form" method="post" class="popup_form registration_form">
			<input type="hidden" name="redirect_to" value="<?php echo esc_attr(esc_url(home_url('/'))); ?>"/>
			<div class="form_left">
				<div class="popup_form_field login_field iconed_field icon-user"><input type="text" id="registration_username_<?php echo esc_attr($unique); ?>" name="registration_username"  value="" placeholder="<?php esc_attr_e('User name (login)', 'trx_utils'); ?>" autocomplete="new-password"></div>
				<div class="popup_form_field email_field iconed_field icon-mail"><input type="text" id="registration_email_<?php echo esc_attr($unique); ?>" name="registration_email" value="" placeholder="<?php esc_attr_e('E-mail', 'trx_utils'); ?>" autocomplete="new-password"></div>
				<?php if (!empty($privacy)) {
					?><div class="popup_form_field agree_field">
						<input type="checkbox" id="i_agree_privacy_policy_sc_form_<?php echo esc_attr($cnt); ?>" name="i_agree_privacy_policy" class="sc_form_privacy_checkbox" value="1">
					<label for="i_agree_privacy_policy_sc_form_<?php echo esc_attr($cnt); ?>"><?php trx_utils_show_layout($privacy); ?></label>
					</div><?php
				}?>

				<div class="popup_form_field submit_field"><input type="submit" class="submit_button" <?php echo (!empty($privacy) ? ' disabled="disabled"' : ''); ?> value="<?php esc_attr_e('Sign Up', 'trx_utils'); ?>"></div>
			</div>
			<div class="form_right">
				<div class="popup_form_field password_field iconed_field icon-lock"><input type="password" id="registration_pwd_<?php echo esc_attr($unique); ?>"  name="registration_pwd"  value="" placeholder="<?php esc_attr_e('Password', 'trx_utils'); ?>" autocomplete="new-password"></div>
				<div class="popup_form_field password_field iconed_field icon-lock"><input type="password" id="registration_pwd2_<?php echo esc_attr($unique); ?>" name="registration_pwd2" value="" placeholder="<?php esc_attr_e('Confirm Password', 'trx_utils'); ?>" autocomplete="new-password"></div>
				<div class="popup_form_field description_field"><?php esc_html_e('Minimum 4 characters', 'trx_utils'); ?></div>
			</div>
		</form>
		<div class="result message_block"></div>
	</div>	<!-- /.registration_wrap -->
</div>		<!-- /.user-popUp -->
