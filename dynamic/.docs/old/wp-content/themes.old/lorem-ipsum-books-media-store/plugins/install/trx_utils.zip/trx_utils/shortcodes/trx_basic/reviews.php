<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('lorem_ipsum_books_media_store_sc_reviews_theme_setup')) {
	add_action( 'lorem_ipsum_books_media_store_action_before_init_theme', 'lorem_ipsum_books_media_store_sc_reviews_theme_setup' );
	function lorem_ipsum_books_media_store_sc_reviews_theme_setup() {
		add_action('lorem_ipsum_books_media_store_action_shortcodes_list', 		'lorem_ipsum_books_media_store_sc_reviews_reg_shortcodes');
		if (function_exists('lorem_ipsum_books_media_store_exists_visual_composer') && lorem_ipsum_books_media_store_exists_visual_composer())
			add_action('lorem_ipsum_books_media_store_action_shortcodes_list_vc','lorem_ipsum_books_media_store_sc_reviews_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_reviews]
*/

if (!function_exists('lorem_ipsum_books_media_store_sc_reviews')) {	
	function lorem_ipsum_books_media_store_sc_reviews($atts, $content = null) {
		if (lorem_ipsum_books_media_store_in_shortcode_blogger()) return '';
		extract(lorem_ipsum_books_media_store_html_decode(shortcode_atts(array(
			// Individual params
			"align" => "right",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . lorem_ipsum_books_media_store_get_css_position_as_classes($top, $right, $bottom, $left);
		$output = lorem_ipsum_books_media_store_param_is_off(lorem_ipsum_books_media_store_get_custom_option('show_sidebar_main'))
			? '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
						. ' class="sc_reviews'
							. ($align && $align!='none' ? ' align'.esc_attr($align) : '')
							. ($class ? ' '.esc_attr($class) : '')
							. '"'
						. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
						. (!lorem_ipsum_books_media_store_param_is_off($animation) ? ' data-animation="'.esc_attr(lorem_ipsum_books_media_store_get_animation_classes($animation)).'"' : '')
						. '>'
					. trim(lorem_ipsum_books_media_store_get_reviews_placeholder())
					. '</div>'
			: '';
		return apply_filters('lorem_ipsum_books_media_store_shortcode_output', $output, 'trx_reviews', $atts, $content);
	}
	lorem_ipsum_books_media_store_require_shortcode("trx_reviews", "lorem_ipsum_books_media_store_sc_reviews");
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'lorem_ipsum_books_media_store_sc_reviews_reg_shortcodes' ) ) {
	//add_action('lorem_ipsum_books_media_store_action_shortcodes_list', 'lorem_ipsum_books_media_store_sc_reviews_reg_shortcodes');
	function lorem_ipsum_books_media_store_sc_reviews_reg_shortcodes() {
	
		lorem_ipsum_books_media_store_sc_map("trx_reviews", array(
			"title" => esc_html__("Reviews", 'trx_utils'),
			"desc" => wp_kses_data( __("Insert reviews block in the single post", 'trx_utils') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"align" => array(
					"title" => esc_html__("Alignment", 'trx_utils'),
					"desc" => wp_kses_data( __("Align counter to left, center or right", 'trx_utils') ),
					"divider" => true,
					"value" => "none",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => lorem_ipsum_books_media_store_get_sc_param('align')
				), 
				"top" => lorem_ipsum_books_media_store_get_sc_param('top'),
				"bottom" => lorem_ipsum_books_media_store_get_sc_param('bottom'),
				"left" => lorem_ipsum_books_media_store_get_sc_param('left'),
				"right" => lorem_ipsum_books_media_store_get_sc_param('right'),
				"id" => lorem_ipsum_books_media_store_get_sc_param('id'),
				"class" => lorem_ipsum_books_media_store_get_sc_param('class'),
				"animation" => lorem_ipsum_books_media_store_get_sc_param('animation'),
				"css" => lorem_ipsum_books_media_store_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'lorem_ipsum_books_media_store_sc_reviews_reg_shortcodes_vc' ) ) {
	//add_action('lorem_ipsum_books_media_store_action_shortcodes_list_vc', 'lorem_ipsum_books_media_store_sc_reviews_reg_shortcodes_vc');
	function lorem_ipsum_books_media_store_sc_reviews_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_reviews",
			"name" => esc_html__("Reviews", 'trx_utils'),
			"description" => wp_kses_data( __("Insert reviews block in the single post", 'trx_utils') ),
			"category" => esc_html__('Content', 'trx_utils'),
			'icon' => 'icon_trx_reviews',
			"class" => "trx_sc_single trx_sc_reviews",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment", 'trx_utils'),
					"description" => wp_kses_data( __("Align counter to left, center or right", 'trx_utils') ),
					"class" => "",
					"value" => array_flip(lorem_ipsum_books_media_store_get_sc_param('align')),
					"type" => "dropdown"
				),
				lorem_ipsum_books_media_store_get_vc_param('id'),
				lorem_ipsum_books_media_store_get_vc_param('class'),
				lorem_ipsum_books_media_store_get_vc_param('animation'),
				lorem_ipsum_books_media_store_get_vc_param('css'),
				lorem_ipsum_books_media_store_get_vc_param('margin_top'),
				lorem_ipsum_books_media_store_get_vc_param('margin_bottom'),
				lorem_ipsum_books_media_store_get_vc_param('margin_left'),
				lorem_ipsum_books_media_store_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Reviews extends LOREM_IPSUM_BOOKS_MEDIA_STORE_VC_ShortCodeSingle {}
	}
}
?>