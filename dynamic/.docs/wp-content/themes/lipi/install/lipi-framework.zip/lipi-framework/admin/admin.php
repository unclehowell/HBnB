<?php
require LIPI_PLUGIN_DIR . '/admin/includes/function.php';
require LIPI_PLUGIN_DIR . '/admin/includes/admin_menu.php';
